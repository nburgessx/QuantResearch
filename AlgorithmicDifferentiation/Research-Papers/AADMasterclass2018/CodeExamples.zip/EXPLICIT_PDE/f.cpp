#include "std_includes.h"

#include "f.h"

int main(int c, char* v[]){
  assert(c==3);
  int n=atoi(v[1]), m=atoi(v[2]);
  vector<double> y(n), p={1e-3,42,0};
  for (int i=0;i<n;i++) y[i]=(i+1)*log(static_cast<double>(i+2));
  f(m,p,y);
  cout << 0 << " " << p[1] << endl;
  for (int i=0;i<n;i++) 
    cout << static_cast<double>(i+1)/(n+1) << " " << y[i] << endl;
  cout << 1 << " " << p[2] << endl;
  return 0;
}
