#include <cstdlib>
#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <cfloat>
#include <stack>
#include <random>
using namespace std;
