#include<cmath>
#include<vector>
#include<cfloat>
#include<cassert>
#include<cstdlib>
#include<iostream>
using namespace std;
