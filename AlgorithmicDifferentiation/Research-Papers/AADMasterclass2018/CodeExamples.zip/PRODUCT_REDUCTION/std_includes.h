#include<cmath>
#include<vector>
#include<cassert>
#include<cfloat>
#include<cstdlib>
#include<iostream>
#include<random>
#include<stack>
