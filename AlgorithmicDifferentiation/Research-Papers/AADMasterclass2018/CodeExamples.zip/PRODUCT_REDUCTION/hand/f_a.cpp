#include "std_includes.h"
using namespace std;

template<typename T>
void f_a(const vector<T>& x, vector<T>& x_a, T& y, T& y_a) {
  assert(x.size()>0);
  stack<T> tbr;
  y=x[0];
  for (size_t i=1;i<x.size();i++) { tbr.push(y); y*=x[i]; }
  double ys=y;
  for (size_t i=x.size()-1;i>0;i--) { 
    y=tbr.top(); tbr.pop(); x_a[i]+=y*y_a; y_a=x[i]*y_a; 
  }
  x_a[0]=y_a; y_a=0;
  y=ys;
}

void driver(vector<double>& x, double &y, vector<double>& g) {
  double y_a=1;
  f_a(x,g,y,y_a);
}  

int main(int c, char* v[]) {
  assert(c==2); int n=atoi(v[1]); assert(n>0);
  vector<double> x(n), g(n); double y;
  for (int i=0;i<n;i++) x[i]=cos(static_cast<double>(i));
  driver(x,y,g);
  cout << y << endl;
  for (int i=0;i<n;i++) cout << g[i] << endl;
  return 0;
}
