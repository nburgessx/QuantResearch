#pragma once
#include "std_includes.h"

template<typename T>
void f(const std::vector<T>& x, T& y) {
  assert(x.size()>0);
  y=x[0];
  for (size_t i=1;i<x.size();i++) y*=x[i];
}
