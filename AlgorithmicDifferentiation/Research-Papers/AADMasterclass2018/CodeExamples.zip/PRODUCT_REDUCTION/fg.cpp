# include "std_includes.h"
# include "f.h"
using namespace std;

void fg(vector<double>& x, double &y, vector<double>& g) {
  double h,yp,ym;
  for (size_t i=0;i<x.size();i++) {
    h=(x[i]<1) ? sqrt(DBL_EPSILON) : sqrt(DBL_EPSILON)*abs(x[i]);  
    x[i]+=h;
    f(x,yp);
    x[i]-=2*h;
    f(x,ym);
    x[i]+=h;
    g[i]=(yp-ym)/(2*h);
    x[i]-=h;
  }
  f(x,y);
}  

int main(int c, char* v[]) {
  assert(c==2); int n=atoi(v[1]); assert(n>0);
  vector<double> x(n), g(n); double y;
  for (int i=0;i<n;i++) x[i]=cos(static_cast<double>(i));
  fg(x,y,g);
  cout << y << endl;
  for (int i=0;i<n;i++) cout << g[i] << endl;
  return 0;
}
