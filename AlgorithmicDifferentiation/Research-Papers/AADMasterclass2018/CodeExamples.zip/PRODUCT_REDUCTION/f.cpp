#include "std_includes.h"
#include "f.h"
using namespace std;

int main(int c, char* v[]) {
  assert(c==2); int n=atoi(v[1]); assert(n>0);
  vector<double> x(n); double y;
  for (int i=0;i<n;i++) x[i]=cos(static_cast<double>(i));
  f(x,y);
  cout << y << endl;
  return 0;
}

