#include "std_includes.h"
#include "f.h"

int main(int c, char* v[]){
  assert(c==3);
  int n=atoi(v[1]), m=atoi(v[2]);
  Matrix<double,Dynamic,1> y(n); 
  for (int i=0;i<n;i++) y(i)=(i+1)*log(static_cast<double>(i+2));
  Matrix<double,3,1> p(3); p(0)=1e-4; p(1)=42; p(2)=0;
  f(m,p,y);
  cout << 0 << " " << p(1) << endl;
  for (int i=0;i<n;i++) 
    cout << static_cast<double>(i+1)/(n+1) << " " << y(i) << endl;
  cout << 1 << " " << p(2) << endl;
  return 0;
}

