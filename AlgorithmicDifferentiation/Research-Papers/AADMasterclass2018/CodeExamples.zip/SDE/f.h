#ifndef __F_H_INCLUDED_
#define __F_H_INCLUDED_

#include "std_includes.h"

template<typename AT, typename PT>
void f(AT& x, const vector<AT>& p, 
    const vector<vector<PT>>& dW) { 
  int m=dW.size(), n=dW[0].size();
  AT s=0, x0=x; PT dt=1./n, t;
  for (int j=0;j<m;j++) {
    t=0;
    for (int i=0;i<n;i++) {
      x+=dt*p[i]*sin(x*t)+p[i]*cos(x*t)*sqrt(dt)*dW[j][i];
      t+=dt;
    }
    s+=x; x=x0;
  }
  x=s/m;
}

#endif
