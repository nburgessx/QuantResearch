#include "std_includes.h"
#include "f.h"

int main(int c, char* v[]) {
  assert(c==3);
  int m=atoi(v[1]), n=atoi(v[2]);
  double x=1;            
  const vector<double> p(n,1); 

  default_random_engine generator;
  normal_distribution<double> distribution(0.0,1.0);
  vector<vector<double>> dW(m,vector<double>(n,1));
  for (int i=0;i<m;i++)
    for (int j=0;j<n;j++)
      dW[i][j]=distribution(generator);

  f(x,p,dW);
  cout << "x=" << x << endl;
  return 0;
}
