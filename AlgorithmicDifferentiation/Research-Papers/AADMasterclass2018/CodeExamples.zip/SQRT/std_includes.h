#include <cstdlib>
#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <cfloat>
#include <stack>
using namespace std;
