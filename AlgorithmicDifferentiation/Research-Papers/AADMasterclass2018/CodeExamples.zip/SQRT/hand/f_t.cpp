#include "std_includes.h"

template<typename T>
void f_t(T& xv, T& xt, const T& pv, const T& pt, const T& eps) {
  while (abs(xv*xv-pv)>eps) {
    xt+=pt/(2*xv)-(3./4.+pv/(4*xv*xv))*xt;
    xv-=(xv*xv-pv)/(2*xv);
  }
}

int main(int c, char* v[]) {
  assert(c==2);
  double pv=atof(v[1]), xv=1;
  double pt=1, xt=0;
  const double eps=1e-12;
  f_t(xv,xt,pv,pt,eps);
  cout << "x=" << xv << endl;
  cout << "dxdp=" << xt << endl;
  return 0;
}

