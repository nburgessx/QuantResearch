#include "std_includes.h"

template<typename T>
void f(T& x, const T& p, const T& eps) {
  while (abs(x*x-p)>eps) x=x-(x*x-p)/(2*x);
}

template<typename T>
void f_sa(const T& xv, T& xa, T& pa) {
  pa+=xa/(2*xv); xa=0;
}

int main(int c, char* v[]) {
  assert(c==2);
  double pv=atof(v[1]), xv=1;
  double pa=0, xa=1;
  const double eps=1e-12;
  f(xv,pv,eps);
  f_sa(xv,xa,pa);
  cout << "x=" << xv << endl;
  cout << "dxdp=" << pa << endl;
  return 0;
}

