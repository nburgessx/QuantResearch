#include "std_includes.h"

template<typename T>
void f_a(T& xv, T& xa, const T& pv, T& pa, const T& eps) {
  stack<T> tbr_T;
  int i=0;
  while (abs(xv*xv-pv)>eps) {
    tbr_T.push(xv);
    xv-=(xv*xv-pv)/(2*xv);
    i++;
  }
  double y=xv;
  for (int j=0;j<i;j++) {
    xv=tbr_T.top(); tbr_T.pop();
    pa+=xa/(2*xv);
    xa-=(3./4.+pv/(4*xv*xv))*xa;
  }
  xv=y;
}

int main(int c, char* v[]) {
  assert(c==2);
  double pv=atof(v[1]), xv=1;
  double pa=0, xa=1;
  const double eps=1e-12;
  f_a(xv,xa,pv,pa,eps);
  cout << "x=" << xv << endl;
  cout << "dxdp=" << pa << endl;
  return 0;
}
