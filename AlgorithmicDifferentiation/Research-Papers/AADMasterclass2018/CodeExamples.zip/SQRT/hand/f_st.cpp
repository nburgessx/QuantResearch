#include "std_includes.h"

template<typename T>
void f(T& x, const T& p, const T& eps) {
  while (abs(x*x-p)>eps) x=x-(x*x-p)/(2*x);
}

template<typename T>
void f_st(const T& xv, T& xt, const T& pt) {
  xt=pt/(2*xv);
}

int main(int c, char* v[]) {
  assert(c==2);
  double pv=atof(v[1]), xv=1;
  double pt=1, xt=0;
  const double eps=1e-12;
  f(xv,pv,eps);
  f_st(xv,xt,pt);
  cout << "x=" << xv << endl;
  cout << "dxdp=" << xt << endl;
  return 0;
}

